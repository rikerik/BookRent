package com.rikerik.BookWave;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControllerTests {

	@Test
	void contextLoads() {
	}

}
