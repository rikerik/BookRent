INSERT INTO users (username, password, email, role) VALUES
('Erik', 'erik1', 'erik@gmail.com', 'USER'),
('Admin', 'admin', 'admin@gmail.com', 'ADMIN'),
('Test', 'test', 'test@gmail.com', 'USER');